function  out= LRFSVM(X,y,pars)%\alpha\rho \eta \psi
% Inputs:
%       X    -- the sample data, dimension, \in\R^{m-by-n}; (required)
%       y    -- the classes of the sample data, \in\R^m; (required)
%               y_i \in {+1,-1}, i=1,2,...,m
%       pars -- parameters (optional)
%
% pars:     Parameters are all OPTIONAL
%               pars.eta   --  Starting point of eta \in\R^m,  (default, zeros(m,1))
%               pars.alpha  --  A positive scalar in (2^-4,2^-6,...,2^4).(default, 1)
% %             pars.theta      --  A positive scalar in (sqrt(2)^-4,...,sqrt(2)^4).(default, 1)
%               pars.maxit   --  Maximum number of iterations, (default,1000)
%               pars.tol     --  Tolerance of the halting condition, (default,1e-3)
%
% Outputs:
%     Out.iter:          Number of iterations
%     Out.time:          CPU time
%     Out.wb:            The solution of the primal problem, namely the classifier
%     Out.q:             The solution q
%     Out.eta:           The solution eta
%     Out.alpha:         The solution alpha
%     Out.nsv:           Number of support vectors
%     Out.s:             Sparsity level of the solution Out.alpha
%     Out.acc:           Classification accuracy
%     Out.error:         Classification error
%%%%%%%    The code was based on the algorithm proposed in
%%%%%%%    Huajun Wang, Wenqian Li
%%%%%%%   Fast ramp fraction loss SVM classifier with low computational complexity
%%%%%%%   for pattern classification




if nargin<3;               pars  = [];                             end
if isfield(pars,'maxit');  maxit = pars.maxit; else; maxit = 1e3;  end
if isfield(pars,'rho');     rho = pars.rho; else; rho = 1;    end
if isfield(pars,'tol');    tol   = pars.tol;   else; tol   = 1e-3; end
if isfield(pars,'alpha'); alpha= pars.alpha;else; alpha     = 1;    end
[m,n]  = size(X);
w      = ones(n,1)/100; % w=zeros(n,1);
eta    = zeros(m,1);
etarho = eta;
D      = GetD(y,m,n);
N      = y.*X;
h      = 1-N*w;
b      = 0;   %b= 1 or -1;
z      = h-b*y;
gamma  = ones(1,4);
Fnorm  = @(var)norm(var)^2;
to     = tic;
flag   = 0;
for iter  = 1:1:maxit
    % update D -------------------------------------
    if alpha/rho>=8/9
       con = sqrt(2*alpha/rho);
       D   = find(z >0 & z <= con);
    elseif alpha/rho<8/9 && alpha/rho>=4/9
       A1   = find(z>0 & z<=3*(alpha/rho)/2);
       A2   = find(z>3*(alpha/rho)/2 & z<=2/3+3*(alpha/rho)/4);
       D    = union(A1,A2);
    else
       B1   = find(z>0 & z<=3*(alpha/rho)/2);
       B2   = find(z>3*(alpha/rho)/2 & z<1/3+3*(alpha/rho)/2);
       B3   = find(z>=1/3+3*(alpha/rho)/2 & z<=1);
       D    = union(union(B1, B2), B3);
     end
    % update q -------------------------------------
    if alpha/rho>=8/9
         q = Prox(z,alpha,rho,D);
    elseif alpha/rho<8/9 && alpha/rho>=4/9
         q = Prox1(z,alpha,rho,A1,A2);
    else
         q = Prox2(z,alpha,rho,B1,B2,B3);
    end
    % update w--------------------------------------
    tmp    = 1 - q - etarho; 
    v      = tmp - b*y;
    nD     = nnz(D);
    ND     = N(D,:);
    if min(n,nD)< 1e3
        NDt     = ND';
        if  n  <= nD
            NND = NDt*ND;
            NND(1:1+n:end) = NND(1:1+n:end) + 1/rho;
            w   = NND\(NDt*v(D));
        else
            if nD >0
                NND = ND *NDt;
                NND(1:1+nD:end) = NND(1:1+nD:end) + 1/rho;
                w  = NDt*(NND\v(D));
            else
                w  = -ones(n,1); D=1;
            end
        end
    else
        if  n  <= nD
            w = my_cg(ND,rho,(v(D)'*ND)',n,1);
        else
            wD = my_cg(ND,rho,v(D),nD,2);
            w  = (wD'*ND)';
        end
    end

    % update D-------------------------------------
    Nw     = N*w;
    b      = mean((tmp(D)-Nw(D)).*y(D));


    % update eta-------------------------------
    etaD   = eta(D);
    eta    = zeros(m,1);
    omega  = Nw + q - 1 + b*y;
    etaD   = etaD + rho * omega(D);
    eta(D) = etaD;


     % stopping crterion --------------------------
    etarho = eta/rho;
    reta   = q  - etarho;
    ind    = (reta<=0 | reta>sqrt(2*alpha/rho));

    gamma(1) = Fnorm(w'+ etaD'*ND)/(1+Fnorm(w));
    gamma(2) = abs(y(D)'*etaD)/(1+nD);
    gamma(3) = Fnorm(omega)/(m+Fnorm(Nw)); %
    if alpha/rho>=8/9
    gamma(4) = Fnorm(q-reta.*ind)/(1+Fnorm(q));
    elseif alpha/rho<8/9 && alpha/rho>=4/9
    gamma(4) = Fnorm(q - Prox1(z,alpha,rho,A1,A2))/(1+Fnorm(q));  
    else
    gamma(4) = Fnorm(q - Prox2(z,alpha,rho,B1,B2,B3))/(1+Fnorm(q));
    end
    error    = max(gamma);
     CPU     = toc(to);
    ACC      = 1-nnz(sign(y.*Nw+b)-y)/length(y);
   tACC(iter)= ACC;
    if error < tol && ACC>0.5; flag=2; break;  end

    z        = reta - omega;
    rho0     = min(z(z>0));
    if isempty(rho0); rho0 = 1e-8; end

    if mod(iter,10)==0
        if gamma(3) > 1e-3
           rho = min(rho*2,10);
        elseif gamma(1) > 1e-3
           rho = min(max(0.01,rho/1.25),5);
        end
    end
 if    m<n || m>10000
    if rho > 2*alpha/rho0^2  % exclude zero solutions
       rho = 1.9*alpha/rho0^2;
    end
 end

 if iter>5 && m>n && m<=10000

 if std(tACC(iter-3:iter))<=1e-3
  Cons = sqrt(2*alpha/rho);  m0   = max(20,2*n);
  D0   = find(z >0 & z <= Cons);

 if nnz(D0)<5 || nnz(D0)>=m0
    flag=1;  z1 = z(find(z>0));
 if nnz(z1)>m0
    s  = mink(z1,m0);    rho = min(2*alpha/s(m0)^2,10000);
 else
 [~,D] = mink(abs(z),m0); flag=0;
  end
  end
  end
  end
end
% fprintf('----------------------------------------------------\n');

out.iter = iter;
out.time = CPU;
out.wb   = [w;b];
out.q    = q;
out.eta  = eta;
out.nsv  = nD;
out.acc  = ACC;
out.error= error;
out.flag = flag;
end

% proxiaml-----------------------------------------------------------------
% proxiaml-----------------------------------------------------------------
function r = Prox(z,alpha,the,D)
if isempty(D)
    tmp1 = sqrt(2*alpha/the);
    D    = find(z >0 & z <= tmp1);
    r    = z;
    r(D) = 0;
   else
    r    = z;
    r(D) = 0;
 end

end

function r = Prox1(z,alpha,the,A1,A2)
   D=union(A1, A2);
if isempty(D)
    tmp1 = sqrt(2*alpha/the);
    D    = find(z >0 & z <= tmp1);
    r    = z;
    r(D) = 0;
else
    r    = z;
    r(A1)= 0;
    r(A2)= z(A2)-3*(alpha/the)/2;
 end

end

function r = Prox2(z,alpha,the,B1,B2,B3)
   D=union(union(B1, B2), B3);
if isempty(D)
    tmp1 = sqrt(2*alpha/the);
    D    = find(z >0 & z <= tmp1);
    r    = z;
    r(D) = 0;
else
    r    = z;
    r(B1)= 0;
    r(B2)= z(B2)-3*(alpha/the)/2;
    r(B3)= (z(B3)-18*alpha/the)/(8-18*alpha/the);
 end

end

% %%% -----------------------------------------------------------------
function D = GetD(y,m,n)
if  m>n
s0      = ceil(n*(log(m/n))^2);
D1      = find(y==1);  nD1= nnz(D1);
D2      = find(y==-1); nD2= nnz(D2);
if  nD1 < s0
    D  = [D1; D2(1:(s0-nD1))];
elseif nD2 < s0
    D  = [D1(1:(s0-nD2)); D2];
else
    D  = [D1(1:ceil(s0/2)); D2(1:(s0-ceil(s0/2)))];
end
D      = sort(D(1:s0));
else
    D  = 1:length(y);
end
end

% Conjugate gradient method-------------------------------------------------
function x = my_cg(ND,rho,b,n,flag)
    x = zeros(n,1);
    r = b;
    e = sum(r.*r);
    t = e;
    for i = 1: 50
        if e < 1e-10*t; break; end
        if  i == 1
            p = r;
        else
            p = r + (e/e0)*p;
        end
        if  flag==1
            w  = p/rho  + ((ND*p)'*ND)';
        else
            w  = p/rho  + ND*(p'*ND)';
        end
        a  = e/sum(p.*w);
        x  = x + a * p;
        r  = r - a * w;
        e0 = e;
        e  = sum(r.*r);
    end

end